# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

# Flask modules
from flask   import Flask, session, render_template, request, redirect, url_for, flash, json, jsonify
from jinja2  import TemplateNotFound

# App modules
from app import app, dbConn, cursor
# from app.models import Profiles

from datetime import datetime


# App main route + generic routing
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/products.html', methods=['GET'])
def SearchProductss():
    sql = "select * from Product"
    cursor.execute(sql)
    products = cursor.fetchall()

    return render_template('products.html', products=products)

@app.route('/payment', methods=['POST','GET'])
def Payment():
    #get user input values from POST request
    name = request.form.get('name')
    memail = "blacksburgfm@gmail.com"
    email = request.form.get('email')
    orderdate = datetime.now().date()

    product = request.form.get('product')
    cartquan = int(request.form.get('quantity'))
    unit_price = float(request.form.get('unit_price'))
    total_price = request.form.get('total_price')
    
    ostatus = "Confirmed"
    smethod = "Ground Shipping"
    pmethod = request.form.get('pmethod')
    cnum = request.form.get('cnum')
    expdate = request.form.get('expdate')
    cvv = request.form.get('cvv')
    saddress = request.form.get('saddress')
    baddress = request.form.get('baddress')

    error = False
    if not name:
        error = True
        flash("Please provide your Full Name")

    if not email:
        error = True
        flash("Please provide an Email")

    if not pmethod:
        error = True
        flash("Please select a Payment Method")

    if not cnum:
        error = True
        flash("Please provide a Card Number")

    if not expdate:
        error = True
        flash("Please provide an Expiration Date")

    if not cvv:
        error = True
        flash("Please provide a CVV")

    if not saddress:
        error = True
        flash("Please provide a Shipping Address")

    if not baddress:
        error = True
        flash("Please provide a Billing Address")

    sql = "select ProductID from Product where ProductName=%s"
    cursor.execute(sql, (product))
    pid = cursor.fetchall()

    if pid:
        prodid = pid[0]['ProductID']
        print("ProductID:", prodid)

    if not error:
        sql2 = "insert into Orders(MerchantEmail,BuyerEmail,OrderDate,TotalQuantity,TotalAmount,OrderStatus,ShippingMethod,ShippingAddress,BillingAddress,PaymentMethod) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        cursor.execute(sql2, [memail,email,orderdate,cartquan,total_price,ostatus,smethod,saddress,baddress,pmethod])
        dbConn.commit()

        sql4 = "select max(OrderID) as ord from Orders"
        cursor.execute(sql4)
        result = cursor.fetchone()
        oid = result["ord"]

        #if oid:
            #ordid = oid[0]['OID']
        print("OrderID", oid)

        sql3 = "insert into OrderDetail(OID,PID,Quantity,Amount) values(%s,%s,%s,%s)"
        cursor.execute(sql3, [oid,prodid,cartquan,total_price])
        dbConn.commit()

        return render_template('orderPlaced.html')
    else:
        return render_template('payment.html',name=name,email=email,pmethod=pmethod,cnum=cnum,expdate=expdate,cvv=cvv,saddress=saddress,baddress=baddress)


@app.route('/orders.html')
def getOrders():
    #retrieve a list of supplier IDs from the northwind database
    sql = "select OrderID from Orders"
    cursor.execute(sql)
    orderids = cursor.fetchall()
    return render_template('orders.html',orderids=orderids)

@app.route("/searchOrders", methods=['GET'])
def SearchOrders():
    #search for the product records for a given supplier ID
    oid = request.args.get('orderid')

    #search for the products records
    sql = "select * from Orders where OrderID=%s"
    cursor.execute(sql, oid)
    orders = cursor.fetchall()

    #sql2 = "select * from Orders"
    #cursor.execute(sql2)
    #orders = cursor.fetchall()

    return render_template('OrderTable.html', orders=orders)

@app.route('/chart')
def graphProducts():

    #have a sql query that generates a 2-dimensional data: for a given supplier, display product name and the corresponding units in stock
    sql = "select OrderID as label,TotalQuantity as value from Orders"
    cursor.execute(sql)
    orders = cursor.fetchall()

    chartData = json.dumps(orders)
    return render_template('OrderChart.html', chartData=chartData)

@app.route('/checkout', methods=['GET'])
def addToCart():
    cartquan = request.args.get('cartquan')
    prod = request.args.get('prod')
    print(prod)

    sql = "select UnitPrice from Product where ProductName=%s"
    cursor.execute(sql, (prod))
    price = cursor.fetchall()

    if price:
        unit_price = price[0]['UnitPrice']
        print("Unit Price:", unit_price)

        # Creating a dictionary to store product and quantity
        cart_item = {
            'product': prod,
            'quantity': cartquan,
            'unit_price': unit_price
        }
        print("Added to cart:", cart_item)

        return render_template('payment.html',cart_item=cart_item, product=prod, quantity=cartquan, unit_priceprice=unit_price)
    else:
        print("No price found for product:", prod)
        return "No price found for product"
    
@app.route('/table', methods=['GET'])
def OrderTable():
    sql = "select * from Orders"
    cursor.execute(sql)
    orders = cursor.fetchall()


@app.route('/form')
def userForm():
    sql = "select * from Shipping"
    cursor.execute(sql)
    shipping = cursor.fetchall()
    return render_template('Order.html',shipping=shipping)


@app.route('/success', methods=['Post', 'Get'])
def addproduct():
    sid = request.form.get("sid")
    vendor = request.form.get("vendor")
    status = request.form.get("status")
    sDate = request.form.get("sDate")
   
    error = False
    if sid and not sid.isnumeric():
        error = True
        flash('Please provide a valid Shipment id')


    if not vendor:
        error = True
        flash('Please provide a Vendor')
    elif vendor.isnumeric():
        error = True
        flash('Please provide a Vendor')
   
    if not status:
        error = True
        flash('Please provide a Shipping Status')
    if not sDate:
        error = True
        flash('Please provide a Shipping Date')


    if not error:


        if not sid:
            sql = "insert into Shipping(Vendor, ShippingDate, ShippingStatus) values(%s, %s, %s);"
            cursor.execute(sql, [vendor, sDate, status])
            dbConn.commit()
            flash("Shipping Order Added")


        else:
            sql = """
            update Shipping
            set Vendor=%s, ShippingDate =%s, ShippingStatus=%s
            where shippingID=%s;
            """
            cursor.execute(sql, [vendor, sDate, status, int(sid)])
            dbConn.commit()
            flash("Shipping Order Updated")




        return render_template('Order.html')
    else:
        return render_template('Order.html', sid=sid, vendor=vendor, sDate=sDate, status=status)
   
@app.route('/delete', methods=['GET', 'POST'])
def delete():
    shipid = request.form.get('shipid')
    error = False
    if shipid and not shipid.isnumeric():
        error = True
        flash('Please provide a valid Shipment id')


    if not error:
        sql = "DELETE FROM Shipping where ShippingID=%s"
        cursor.execute(sql, [shipid])
        dbConn.commit()
        flash("Shipping Record Deleted")
    return render_template('order.html')


@app.route('/search')
def search():
    sql = "select * from Shipping"
    cursor.execute(sql)
    shipids = cursor.fetchall()
    return render_template('Search.html', shipids=shipids)


@app.route('/searchMerchantOrder', methods=['GET'])
def SearchProducts():
    sid = request.args.get('sid')


    sql = "select * from Shipping where ShippingID=%s"
    cursor.execute(sql, sid)
    orders = cursor.fetchall()


    return render_template('ShippingTable.html', orders=orders)


@app.route('/visual')
def visual():
    sql = "select Distinct ShippingStatus from Shipping"
    cursor.execute(sql)
    shipids = cursor.fetchall()
    return render_template('visual.html',shipids=shipids)


@app.route('/shipchart')
def chartData():
    status = request.args.get('shipid')


    #have a sql query that generates a 2-dimensional data: for a given supplier, display product name and the corresponding units in stock
    sql = "select ShippingStatus as label, Count(Vendor) as value from Shipping where ShippingStatus=%s"
    print(cursor.mogrify(sql, status))
    cursor.execute(sql, status)
    merchantOrder = cursor.fetchall()


    chartData = json.dumps(merchantOrder)
    return render_template('shipChart.html', chartData=chartData)

@app.route('/addproduct', methods=['GET'])
def add_product_form():
    return render_template('AddProduct.html')


@app.route('/addproduct', methods=['POST'])
def add_product():
    product_id = request.form['ProductID']
    product_name = request.form['ProductName']
    product_description = request.form['ProductDescription']
    unit_price = float(request.form['UnitPrice'])
    quantity = int(request.form['Quantity'])
    category = request.form['PCategory']
    product_image = request.form['ProductImage']


    try:
        sql = "INSERT INTO Product (ProductID, ProductName, ProductDescription, UnitPrice, Quantity, PCategory, ProductImage) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        values = (product_id, product_name, product_description, unit_price, quantity, category, product_image)
        cursor.execute(sql, values)
        dbConn.commit()
       
        flash("Product added successfully!", "success")


        return redirect(url_for('add_product_form'))
    except Exception as e:
        flash("Failed to add product. Error: " + str(e), "error")
        return redirect(url_for('add_product_form'))


def get_all_product_ids():
    try:
        cursor.execute("SELECT ProductID FROM Product")
        product_ids = cursor.fetchall()
        return [product['ProductID'] for product in product_ids]
    except Exception as e:
        print("Error fetching product IDs:", e)
        return []


# Define the update_product function
def update_product(product_id, product_name, product_description, unit_price, quantity, category, product_image):
    try:
        # Execute SQL UPDATE statement to modify product details in the database
        sql = "UPDATE Product SET ProductName=%s, ProductDescription=%s, UnitPrice=%s, Quantity=%s, PCategory=%s, ProductImage=%s WHERE ProductID=%s"
        values = (product_name, product_description, unit_price, quantity, category, product_image, product_id)
        cursor.execute(sql, values)
        dbConn.commit()
    except Exception as e:
        print("Error updating product:", e)


# Define your Flask routes here
@app.route('/modifyproduct', methods=['GET', 'POST'])
def modify_product():
    if request.method == 'GET':
        products = get_all_product_ids()  
        return render_template('ModifyProduct.html', products=products)
   
    elif request.method == 'POST':
        # Get form data
        product_id = request.form['ProductID']
        product_name = request.form['ProductName']
        product_description = request.form['ProductDescription']
        unit_price = request.form['UnitPrice']
        quantity = request.form['Quantity']
        category = request.form['PCategory']
        product_image = request.form['ProductImage']


        # Update product details in the database
        try:
            update_product(product_id, product_name, product_description, unit_price, quantity, category, product_image)
            dbConn.commit()
            flash("Product modified successfully!", "success")
        except Exception as e:
            print("Error updating product:", e)
            flash("Error updating product: " + str(e), "danger")


        # Get all product IDs again to render the template
        products = get_all_product_ids()
        return render_template('ModifyProduct.html', products=products)


# Ensure to initialize your Flask app and run it
if __name__ == "__main__":
    app.run(debug=True)


@app.route('/deleteproduct', methods=['POST'])
def delete_product():
    if request.method == 'POST':
        # Get the product ID from the form
        product_id = request.form['ProductID']


        try:
            # Execute SQL DELETE statement to remove the product from the database
            sql = "DELETE FROM Product WHERE ProductID = %s"
            cursor.execute(sql, (product_id,))
            dbConn.commit()


            flash("Product deleted successfully!", "success")
        except Exception as e:
            print("Error deleting product:", e)
            flash("Error deleting product: " + str(e), "danger")


        # Redirect back to the delete product form
        return redirect(url_for('delete_product_form'))


# Add this route to render the delete product form
@app.route('/deleteproduct', methods=['GET'])
def delete_product_form():
    return render_template('DeleteProduct.html')


# Add this route to handle the search product functionality
@app.route('/searchproduct', methods=['POST'])
def search_product():
    if request.method == 'POST':
        # Get the product ID from the form
        product_id = request.form['ProductID']


        try:
            # Execute SQL SELECT statement to retrieve product details from the database
            sql = "SELECT * FROM Product WHERE ProductID = %s"
            cursor.execute(sql, (product_id,))
            product = cursor.fetchone()


            # Get the maximum quantity to use for the progress bar
            max_quantity = get_max_quantity()


            return render_template('SearchProduct.html', product=product, max_quantity=max_quantity)
        except Exception as e:
            print("Error searching product:", e)
            flash("Error searching product: " + str(e), "danger")


        # Redirect back to the search product form
        return redirect(url_for('search_product_form'))


# Add this function to retrieve the maximum quantity of all products
def get_max_quantity():
    try:
        cursor.execute("SELECT MAX(Quantity) AS MaxQuantity FROM Product")
        max_quantity = cursor.fetchone()['MaxQuantity']
        return max_quantity if max_quantity else 0
    except Exception as e:
        print("Error fetching maximum quantity:", e)
        return 0


# Add this route to render the search product form
@app.route('/searchproduct', methods=['GET'])
def search_product_form():
    return render_template('SearchProduct.html')




@app.route('/inventorylevel')
def inventory_level():
    # Fetch inventory data from the database
    cursor.execute("SELECT ProductID, ProductName, Quantity, ProductImage FROM Product ORDER BY ProductID")
    inventory_data = cursor.fetchall()


    return render_template('InventoryLevel.html', inventory_data=inventory_data)


# Login App routing
@app.route('/logIn', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
       
        # Check if the username and password match the database
        sql = "SELECT * FROM UserProfile WHERE email = %s AND UPassword = %s"
        cursor.execute(sql, (username, password))
        user = cursor.fetchone()
       
        if user:
            return render_template('redirectButton.html',username=username,password=password)
        else:
            return jsonify({'success': False}), 401


    # Render the login page
    return render_template('logIn.html')


# Create Profile App routing
@app.route('/createProfile', methods=['POST', 'GET'])
def create_profile():
    if request.method == 'POST':
        # Retrieve form data
        email = request.form.get('email')
        user_type = request.form.get('userType')
        contact_first_name = request.form.get('contact_first_name')
        contact_last_name = request.form.get('contact_last_name')
        password = request.form.get('password')
        phone = request.form.get('phone')
        website = request.form.get('website')
        business_name = request.form.get('businessName')
        time_of_creation = datetime.now()



        # Insert data into the UserProfile table
        sql = "INSERT INTO UserProfile (Email,UserType, ContactFirstName, ContactLastName, UPassword, Phone, Website, BusinessName, TimeOfCreation) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
        values = (email, user_type, contact_first_name, contact_last_name, password, phone, website, business_name, time_of_creation)
        cursor.execute(sql, values)
        dbConn.commit()


        # Redirect to a success page or perform any other action
        return redirect(url_for('index'))
    else:
        # Render the template for creating a new profile
        return render_template('createProfile.html')


# Delete Profile App routing
@app.route('/deleteProfile', methods=['POST', 'GET'])
def delete_profile():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
       
        # Validate credentials
        if valid_credentials(username, password):
            # Delete the profile from the database
            sql = "DELETE FROM UserProfile WHERE email = %s"
            cursor.execute(sql, (username,))
            dbConn.commit()
           
            
            return redirect(url_for('index'))
        else:
            return "Error"
   
    return render_template('deleteProfile.html')


# Profile Visualization routing
@app.route('/profileCharts')
def profile_charts():
    # Query to count the number of user types in the database
    sql = "SELECT UserType as label, COUNT(*) as value FROM UserProfile GROUP BY UserType"
    cursor.execute(sql)
    user_counts = cursor.fetchall()
    
    chartData = json.dumps(user_counts)
    return render_template('profileCharts.html', chartData=chartData)
   


# Modify Profile Routing
def valid_credentials(username, password):
    # Check if the provided username and password exist in the database
    sql = "SELECT * FROM UserProfile WHERE email = %s AND UPassword = %s"
    cursor.execute(sql, (username, password))
    user = cursor.fetchone()
    if user:
        return True
    else:
        return False


@app.route('/modifyProfile', methods=['POST', 'GET'])
def modify_profile():
    if request.method == 'POST':
        username = request.form.get('email')
        password = request.form.get('password')
        fname = request.form.get('fname')
        lname = request.form.get('lname')
        newpass = request.form.get('newPassword')
        phone = request.form.get('phone')
        website = request.form.get('website')
        businessname = request.form.get('businessName')
       
        # Update the profile information in the database
        sql = "UPDATE UserProfile SET ContactFirstName=%s, ContactLastName=%s, UPassword=%s, Phone=%s, Website=%s, BusinessName=%s WHERE Email=%s"
        values = (fname,lname,newpass,phone,website,businessname,username)
        cursor.execute(sql, values)
        dbConn.commit()
           
        flash('Profile modified successfully!', 'success')
        return redirect(url_for('index'))
   
    return render_template('modifyProfile.html')

# redirect button routing
@app.route('/redirectButton')
def redirect_button():
    return render_template('redirectButton.html')

@app.route('/deleteOrder', methods=['POST','GET'])
def deleteOrder():
    ordid = request.args.get('orderid')

    sql = "delete from Orders where OrderID=%s"
    cursor.execute(sql, (ordid))
    dbConn.commit()

    return render_template('orders.html')








