# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

# Import core packages
import os

# Import Flask 
from flask import Flask
import pymysql

dbConn = pymysql.connect(
    host="office.scholars.bond",
    port=3309,
    user="bit4444group19",
    password="eYw.-fTSqY6S",
    database="bit4444group19",
    cursorclass=pymysql.cursors.DictCursor
)

cursor = dbConn.cursor()

# Inject Flask magic
app = Flask(__name__)
app.secret_key = "mdmd090420mdmd"


# Import routing to render the pages
from app import views
